import React from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import store from './redux/store/store'



import Login from "./components/auth/Login";
import SignUp from "./components/auth/Register";

//import HomePage from "./components/modules/HomePage";

import landingProduct from "./components/modules/landingProduct";
import createProduct from "./components/modules/createProduct";
import updateProduct from "./components/modules/updateProduct";
import deleteProduct from "./components/modules/deleteProduct";
import findByIdProduct from "./components/modules/findByIdProduct";
import findByCategoryProduct from "./components/modules/findByCategoryProduct";
import showProduct from "./components/modules/showProduct";

import landingStock from "./components/modules/landingStock";
import createStock from "./components/modules/createStock";
import updateStock from "./components/modules/updateStock";
import deleteStock from "./components/modules/deleteStock";
import findByIdStock from "./components/modules/findByIdStock";
import showStock from "./components/modules/showStock";

import landingReview from "./components/modules/landingReview";
import createReview from "./components/modules/createReview";
import updateReview from "./components/modules/updateReview";
import deleteReview from "./components/modules/deleteReview";
import findByIdReview from "./components/modules/findByIdReview";

import landingPrice from "./components/modules/landingPrice";
import createPrice from "./components/modules/createPrice";
import updatePrice from "./components/modules/updatePrice";
import deletePrice from "./components/modules/deletePrice";
import findByIdPrice from "./components/modules/findByIdPrice";
import HomePage from './components/modules/HomePage';
import { Provider } from 'react-redux';



function App() {
  return (
    <Provider store = { store } >
    <Router>
    <div className="App">
      <div className="auth-wrapper">
        <div className="auth-inner">
          <Switch>
          
            <Route exact path='/' component={Login} />
            <Route path="/sign-in" component={Login} />
            <Route path="/sign-up" component={SignUp} />
            <Route path="/HomePage" component={HomePage} />

            <Route path="/landingProduct" component={landingProduct} />
            <Route path="/createProduct" component={createProduct} />
            <Route path="/updateProduct" component={updateProduct} />
            <Route path="/deleteProduct" component={deleteProduct} />
            <Route path="/findByIdProduct" component={findByIdProduct} />
            <Route path="/showProduct" component={showProduct} />
            <Route path="/findByCategoryProduct" component={findByCategoryProduct} />

            <Route path="/landingStock" component={landingStock} />
            <Route path="/createStock" component={createStock} />
            <Route path="/updateStock" component={updateStock} />
            <Route path="/deleteStock" component={deleteStock} />
            <Route path="/findByIdStock" component={findByIdStock} />
            <Route path="/showStock" component={showStock} />

            <Route path="/landingReview" component={landingReview} />
            <Route path="/createReview" component={createReview} />
            <Route path="/updateReview" component={updateReview} />
            <Route path="/deleteReview" component={deleteReview} />
            <Route path="/findByIdReview" component={findByIdReview} />

            <Route path="/landingPrice" component={landingPrice} />
            <Route path="/createPrice" component={createPrice} />
            <Route path="/updatePrice" component={updatePrice} />
            <Route path="/deletePrice" component={deletePrice} />
            <Route path="/findByIdPrice" component={findByIdPrice} />
          </Switch>
        </div>
      </div>
    </div>
   

    </Router>
    </Provider>
  );
}

export default App;