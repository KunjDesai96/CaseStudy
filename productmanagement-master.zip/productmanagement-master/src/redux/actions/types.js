export const GET_ERROR = 'GET_ERROR';
export const CLEAR_ERRORS = 'CLEAR_ERRORS';
export const REGISTER_SUCCESS = 'REGISTER_SUCCESS';
export const REGISTER_FAIL = 'REGSITER_FAIL';
export const LOGIN_SUCCESS  = 'LOGIN_SUCCESS';
export const LOGIN_FAIL = 'LOGIN_FAIL';
export const LOGIN_FAILED = 'LOGIN_FAILED';
export const LOGOUT = 'LOGOUT';
