import {LOGIN_FAIL, LOGIN_SUCCESS, LOGOUT, REGISTER_SUCCESS, LOGIN_FAILED} from '../actions/types'
const initialState = {
token : localStorage.getItem('token'),
isAuthenticated : false,
loading : true,
user:null,
login_failed: false,
register_success: false
}

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {

    case REGISTER_SUCCESS:
        return { ...state, ...payload,
        isAuthenticated:true, login_failed: false, register_success: true}

        case LOGIN_SUCCESS:
            return {
                ...state,
                ...payload,
                isAuthenticated:true,
                login_failed:false
            }
            case LOGOUT:{
                return {
                    ...state,
                    token : null,
                    isAuthenticated:false,
                    user :null,
                    login_failed:false
                }
            }
            case LOGIN_FAIL:{
                return {
                    ...state,
                    token : null,
                    isAuthenticated:false,
                    user :null,
                    login_failed:true
                }
            }
            case LOGIN_FAILED:{
                return {
                    ...state,
                    token : null,
                    isAuthenticated:false,
                    user :null,
                    login_failed:false
                }
            }
    default:
        return state
    }
}