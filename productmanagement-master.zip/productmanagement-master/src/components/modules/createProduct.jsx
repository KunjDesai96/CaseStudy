import React, { useState , Component} from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import axios from 'axios'
import Header from '../layouts/Header'
import Footer from '../layouts/Footer'

export const CreateProduct = ({ isAuthenticated }) => {
  const [productData, setProductData] = useState({productName: '', category:'', description:'', expiryDate:''})
  const [res, setRes] = useState();
  const [notFound, setNotFound] = useState();
    const  {productName, category, description, expiryDate} = productData;
    const handleChange = (event) => {
        setProductData({...productData, [event.target.name]: event.target.value,})
      };
    const onSubmit = (e) => {
        e.preventDefault();
        const productDetails = {
          productName: productName,
          category: category,
          description: description,
          expiryDate: expiryDate
        };
        axios
          .post("http://localhost:9006/api/v1/product/", productDetails)
          .then( res => setRes(res.data)) 
          .catch((err) => setNotFound(true));
          
      };
      if(isAuthenticated)
      {

      
    return (


        <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
        <h3>Product</h3>

        <div className="form-group">
            <label>Product Name</label>
            <input
            type="text"
            className="form-control"
            placeholder="Product Name"
            name="productName"
            value={productName}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
            <label>Category</label>
                    <input type="text" className="form-control" name="category" placeholder="Category" value={category} required
            onChange={handleChange} />
        </div>

        <div className="form-group">
            <label>Description</label>
            <input type="text" className="form-control" name="description" placeholder="Description"  value={description}
            onChange={handleChange} />
        </div>

        <div className="form-group">
            <label>Expiry Date</label>
            <input type="date" className="form-control" name="expiryDate" placeholder="Expiry Date"  value={expiryDate}
            onChange={handleChange} />
        </div>
        <button type="submit" className="btn btn-primary btn-block">Submit</button>
        <br/>
    </form>
    { res && <h4 className="output">Product added successfully</h4>}
    {notFound && <h4 className="fail">Expiry Date cannot be in the past.</h4>}
    <Footer> </Footer>
    </div>
    )
}
else
{
  return <div> Please login to access this page</div>
}
}

CreateProduct.propTypes = {
  isAuthenticated: PropTypes.bool,
}

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated
  
})

const mapDispatchToProps = {
  
}

export default connect(mapStateToProps, mapDispatchToProps)(CreateProduct)
