import React, { useState , Component} from 'react'
import PropTypes from 'prop-types'
import { Link } from "react-router-dom";
import { connect } from 'react-redux'
import axios from 'axios'
import Header from '../layouts/Header'
import Footer from '../layouts/Footer'

export const LandingPrice = ({ isAuthenticated }) => {
    if(isAuthenticated)
    {
    return (
        <div>
            <Header></Header>
            <form >
                <h3>This is the Price Page</h3>
                <div>
                    <p>Please choose an operation from below</p>
                    <ul>
                        <br /><li><Link to="/createPrice">Create a Price</Link></li><br />
                        <li><Link to="/updatePrice">Update a Price</Link></li><br />
                        <li><Link to="/deletePrice">Delete a Price</Link></li><br />
                        <li><Link to="/findByIdPrice">Find a Price of Product by ID</Link></li><br />
                    </ul>
                </div>

            </form>
            <Footer> </Footer>
        </div>
    )
}
else
{
  return <div> Please login to access this page</div>
}
}


LandingPrice.propTypes = {
    isAuthenticated: PropTypes.bool,
}

const mapStateToProps = (state) => ({
    isAuthenticated: state.auth.isAuthenticated

})

const mapDispatchToProps = {
    
}

export default connect(mapStateToProps, mapDispatchToProps)(LandingPrice)
