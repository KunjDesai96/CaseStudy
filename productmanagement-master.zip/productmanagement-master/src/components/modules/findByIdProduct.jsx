import React, { Component, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";
import Table from "react-bootstrap/Table";

export const FindByIdProduct = ({ isAuthenticated }) => {
  const [productData, setProductData] = useState({ productId: "" });
  const { productId } = productData;
  const [resData, setResData] = useState({
    productId: "",
    productName: "",
    category: "",
    description: "",
    expiryData: "",
  });
  //const {productName, category, description, expiryData} = resData;
  const [notFound, setNotFound] = useState();
  const handleChange = (event) => {
    setProductData({ ...productData, [event.target.name]: event.target.value });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    const productDetails = {
      productId: productId,
    };
    axios
      .get("http://localhost:9006/api/v1/product/" + productData.productId)
      .then((res) => setResData(res.data))
      .catch((err) => setNotFound(true));
  };
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
          <h3>Search Product By Id</h3>

          <div className="form-group">
            <label>Product Id</label>
            <input
              type="text"
              className="form-control"
              placeholder="Product Id"
              name="productId"
              value={productId}
              onChange={handleChange}
            />
          </div>
          <button type="submit" className="btn btn-primary btn-block">
            Search
          </button>
        </form>
        <br />
        {notFound && <h4 className="fail">Prouct Not Found</h4>}
        {resData.productName != "" && (
          <Table striped bordered hover size="sm">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Description</th>
                <th>Expiry date</th>
              </tr>
            </thead>
            <tbody>
              {
                <tr key={productData.productId}>
                  <td>{productData.productId}</td>
                  <td>{resData.productName}</td>
                  <td>{resData.category}</td>
                  <td>{resData.description}</td>
                  <td>{resData.expiryDate}</td>
                </tr>
              }
            </tbody>
          </Table>
        )}
        <Footer> </Footer>
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};
FindByIdProduct.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(FindByIdProduct);
