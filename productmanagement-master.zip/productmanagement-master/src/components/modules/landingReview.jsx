import React, { useState , Component} from 'react'
import PropTypes from 'prop-types'
import { Link } from "react-router-dom";
import { connect } from 'react-redux'
import axios from 'axios'
import Header from '../layouts/Header'
import Footer from '../layouts/Footer'

export const LandingReview =({ isAuthenticated }) => {
    if(isAuthenticated)
    {
    return (
        <div>
            <Header></Header>
            <form >
                <h3>This is the Review Page</h3>
                <div>
                    <p>Please choose an operation from below</p>
                    <ul>
                        <br /><li><Link to="/createReview">Create a Review</Link></li><br />
                        <li><Link to="/updateReview">Update a Review</Link></li><br />
                        <li><Link to="/deleteReview">Delete a Review</Link></li><br />
                        <li><Link to="/findByIdReview">Find a Review by ID</Link></li><br />
                    </ul>
                </div>

            </form>
            <Footer> </Footer>
        </div>
       )
    }
    else
    {
      return <div> Please login to access this page</div>
    }
    }

LandingReview.propTypes = {
    isAuthenticated: PropTypes.bool,
}

const mapStateToProps = (state) => ({
    isAuthenticated: state.auth.isAuthenticated

})

const mapDispatchToProps = {
    
}

export default connect(mapStateToProps, mapDispatchToProps)(LandingReview)
