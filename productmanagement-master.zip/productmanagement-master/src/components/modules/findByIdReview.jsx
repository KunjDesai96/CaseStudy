import React, { Component, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";
import Table from "react-bootstrap/Table";

export const FindByIdReview = ({ isAuthenticated }) => {
  const [productData, setProductData] = useState({ reviewId: "" });
  const { reviewId } = productData;
  const [resData, setResData] = useState({
    reviewId: "",
    userName: "",
    rating: "",
    comment: "",
  });
  //const {productName, category, description, expiryData} = resData;
  const [notFound, setNotFound] = useState();
  const handleChange = (event) => {
    setProductData({ ...productData, [event.target.name]: event.target.value });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    const productDetails = {
      reviewId: reviewId,
    };
    axios
      .get("http://localhost:9009/api/v1/review/" + productData.reviewId)
      .then((res) => setResData(res.data))
      .catch((err) => setNotFound(true));
  };
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
          <h3>Search Review By Id</h3>

          <div className="form-group">
            <label>Review Id</label>
            <input
              type="text"
              className="form-control"
              placeholder="Review Id"
              name="reviewId"
              value={reviewId}
              onChange={handleChange}
            />
          </div>
          <button type="submit" className="btn btn-primary btn-block">
            Search
          </button>
        </form>
        <br />
        {notFound && <h4 className="fail">Review Not Found</h4>}
        {resData.userName != "" && (
          <Table striped bordered hover size="sm">
            <thead>
              <tr>
                <th>ID</th>
                <th>Product ID</th>
                <th>User Name</th>
                <th>Rating</th>
                <th>Comments</th>
              </tr>
            </thead>
            <tbody>
              {
                <tr key={productData.reviewId}>
                  <td>{resData.reviewId}</td>
                  <td>{resData.productId}</td>
                  <td>{resData.userName}</td>
                  <td>{resData.rating}</td>
                  <td>{resData.comment}</td>
                </tr>
              }
            </tbody>
          </Table>
        )}
        <Footer> </Footer>
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};
FindByIdReview.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(FindByIdReview);
