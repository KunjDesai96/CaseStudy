import React, { Component,useState, useEffect } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import axios from 'axios'
import Header from '../layouts/Header'
import Footer from '../layouts/Footer'
import Table from 'react-bootstrap/Table'

export const ShowProduct = ({ isAuthenticated }) => {
    const [state, setState] = useState([{productId : "", productName: "", category:"", description:"", expiryDate:""}])
    //const  {productId, productName, category, description, expiryDate} = state;
    useEffect(() => {
        axios
        //.get("http://localhost:5000/api/v1/product/")
        .get("http://localhost:9006/api/v1/product/")
        .then( res => setState(res.data))
    })
    if(isAuthenticated)
    {
    return (
        <div>
        <Header></Header>
        <h4>Product Details</h4>
        <Table striped bordered hover size="sm">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th>Expiry date</th>
                </tr>
            </thead>
            <tbody>
                {
                    state.map((item) => (
                        <tr key={item.productId}>
                            <td>{item.productId}</td>
                            <td>{item.productName}</td>
                            <td>{item.category}</td>
                            <td>{item.description}</td>
                            <td>{item.expiryDate}</td>
                        </tr>
                    ))
                }
            </tbody>
        </Table>
        <Footer> </Footer>
    </div>
       
         )
}
else
{
  return <div> Please login to access this page</div>
}}

ShowProduct.propTypes = {
    isAuthenticated: PropTypes.bool,
}

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated
  
})

const mapDispatchToProps = {
    
}

export default connect(mapStateToProps, mapDispatchToProps)(ShowProduct)
