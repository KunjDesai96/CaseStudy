import React, { Component, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";

export const DeleteStock = ({ isAuthenticated }) => {
  const [stockData, setStockData] = useState({ stockId: "" });
  const { stockId } = stockData;
  const [res, setRes] = useState();
  const [notFound, setNotFound] = useState();
  const handleChange = (event) => {
    setStockData({ ...stockData, [event.target.name]: event.target.value });
  };
  const onSubmit = (e) => {
    const priceDetails = {
      stockId: stockId,
    };
    e.preventDefault();
    axios
      .delete("http://localhost:9007/api/v1/stock/" + priceDetails.stockId)
      .then((res) => setRes(res.data))
      .catch((err) => setNotFound(true));
  };
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
          <h3>Delete Stock</h3>

          <div className="form-group">
            <label>Stock ID</label>
            <input
              type="text"
              className="form-control"
              placeholder="Stock ID"
              name="stockId"
              value={stockId}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-primary btn-block">
            Delete
          </button>
          <br />
          {res && <h4 className="output">Stock deleted successfully</h4>}
          {notFound && <h4 className="fail">Something went wrong</h4>}
          <Footer> </Footer>
        </form>
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};
DeleteStock.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(DeleteStock);
