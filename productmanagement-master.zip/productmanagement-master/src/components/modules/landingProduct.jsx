import React, { useState , Component} from 'react'
import PropTypes from 'prop-types'
import { Link } from "react-router-dom";
import { connect } from 'react-redux'
import axios from 'axios'
import Header from '../layouts/Header'
import Footer from '../layouts/Footer'


export const LandingProduct = ({ isAuthenticated }) => {
    if(isAuthenticated)
    {
    return (
        <div>
            <Header></Header>
            <form >
                <h3>This is the Product Page</h3>
                <div>
                    <p>Please choose an operation from below</p>
                    <ul>
                        <br /><li><Link to="/createProduct">Create a Product</Link></li><br />
                        <li><Link to="/updateProduct">Update a Product</Link></li><br />
                        <li><Link to="/deleteProduct">Delete a Product</Link></li><br />
                        <li><Link to="/findByIdProduct">Find a Product by ID</Link></li><br />
                        <li><Link to="/showProduct">Show all Products</Link></li><br />
                        <li><Link to="/findByCategoryProduct">Find a Product by Category</Link></li><br />
                    </ul>
                </div>
               
            </form>
            <Footer> </Footer>
        </div>
        )
    }
    else
    {
      return <div> Please login to access this page</div>
    }
    }

LandingProduct.propTypes = {
    isAuthenticated: PropTypes.bool,}

const mapStateToProps = (state) => ({
    isAuthenticated: state.auth.isAuthenticated

})

const mapDispatchToProps = {
    
}

export default connect(mapStateToProps, mapDispatchToProps)(LandingProduct)
