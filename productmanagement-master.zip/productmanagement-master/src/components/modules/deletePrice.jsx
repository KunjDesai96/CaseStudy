import React, { Component, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";

export const DeletePrice = ({ isAuthenticated }) => {
  const [priceData, setPriceData] = useState({ priceId: "" });
  const [res, setRes] = useState();
  const [notFound, setNotFound] = useState();
  const { priceId } = priceData;
  const handleChange = (event) => {
    setPriceData({ ...priceData, [event.target.name]: event.target.value });
  };
  const onSubmit = (e) => {
    const priceDetails = {
      priceId: priceId,
    };
    e.preventDefault();
    axios
      .delete("http://localhost:9008/api/v1/price/" + priceDetails.priceId)
      .then((res) => setRes(res.data))
      .catch((err) => setNotFound(true));
  };
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
          <h3>Delete Price</h3>

          <div className="form-group">
            <label>Price ID</label>
            <input
              type="text"
              className="form-control"
              placeholder="Price ID"
              name="priceId"
              value={priceId}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-primary btn-block">
            Delete
          </button>
        </form>
        <br />
        {res && <h4 className="output">Price deleted successfully</h4>}
        {notFound && <h4 className="fail">Something went wrong</h4>}
        <Footer> </Footer>
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};

DeletePrice.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(DeletePrice);
