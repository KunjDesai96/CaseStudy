import React, { Component, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";

export const CreateStock = ({ isAuthenticated }) => {
  const [stockData, setStockData] = useState({
    productId: "",
    quantity: "",
    location: "",
  });
  const { productId, quantity, location } = stockData;
  const [res, setRes] = useState();
  const [notFound, setNotFound] = useState();
  const handleChange = (event) => {
    setStockData({ ...stockData, [event.target.name]: event.target.value });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    const stockDetails = {
      productId: productId,
      quantity: quantity,
      location: location,
    };
    axios
      .post("http://localhost:9007/api/v1/stock/", stockDetails)
      .then((res) => setRes(res.data))
      .catch((err) => setNotFound(true));
  };
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
          <h3>Stock</h3>

          <div className="form-group">
            <label>Product ID</label>
            <input
              type="text"
              className="form-control"
              placeholder="Product ID"
              name="productId"
              value={productId}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>Quantity</label>
            <input
              type="text"
              className="form-control"
              name="quantity"
              placeholder="Quantity"
              value={quantity}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>Location</label>
            <input
              type="text"
              className="form-control"
              name="location"
              placeholder="Location"
              value={location}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-primary btn-block">
            Submit
          </button>
          <br />
        </form>
        {res && <h4 className="output">Stock added successfully</h4>}
        {notFound && <h4 className="fail">Product Id does not exists.</h4>}
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};

CreateStock.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(CreateStock);
