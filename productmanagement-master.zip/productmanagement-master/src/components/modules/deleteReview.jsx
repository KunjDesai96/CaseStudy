import React, { Component, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";

export const DeleteReview = ({ isAuthenticated }) => {
  const [reviewData, setReviewData] = useState({ reviewId: "" });
  const { reviewId } = reviewData;

  const [res, setRes] = useState();
  const [notFound, setNotFound] = useState();
  const handleChange = (event) => {
    setReviewData({ ...reviewData, [event.target.name]: event.target.value });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    const reviewDetails = {
      reviewId,
    };
    axios
      .delete("http://localhost:9009/api/v1/review/" + reviewDetails.reviewId)
      .then((res) => setRes(res.data))
      .catch((err) => setNotFound(true));
  };
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
          <h3>Delete Review</h3>

          <div className="form-group">
            <label>Review ID</label>
            <input
              type="text"
              className="form-control"
              placeholder="Review ID"
              name="reviewId"
              value={reviewId}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-primary btn-block">
            Delete
          </button>
        </form>
        <br />
        {res && <h4 className="output">Review deleted successfully</h4>}
        {notFound && <h4 className="fail">Something went wrong</h4>}
        <Footer> </Footer>
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};

DeleteReview.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(DeleteReview);
