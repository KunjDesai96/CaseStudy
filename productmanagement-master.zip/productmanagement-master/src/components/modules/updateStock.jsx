import React, { useState, Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";

export const UpdateStock = ({ isAuthenticated }) => {
  const [stockData, setStockData] = useState({
    stockId: "",
    productId: "",
    quantity: "",
    location: "",
  });
  const [res, setRes] = useState();
  const [notFound, setNotFound] = useState();
  const { stockId, productId, quantity, location } = stockData;
  const handleChange = (event) => {
    setStockData({ ...stockData, [event.target.name]: event.target.value });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    const stockDetails = {
      stockId: stockId,
      productId: productId,
      quantity: quantity,
      location: location,
    };
    axios
      .put(
        "http://localhost:9007/api/v1/stock/" + stockDetails.stockId,
        stockDetails
      )
      .then((res) => setRes(res.data))
      .catch((err) => setNotFound(true));
  };
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
          <h3>Update Stock</h3>

          <div className="form-group">
            <label>Stock ID</label>
            <input
              type="text"
              className="form-control"
              placeholder="Stock ID"
              name="stockId"
              value={stockId}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>Product ID</label>
            <input
              type="text"
              className="form-control"
              placeholder="Product ID"
              name="productId"
              value={productId}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>New Quantity</label>
            <input
              type="text"
              className="form-control"
              name="quantity"
              placeholder="New QUuantity"
              value={quantity}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>New Location</label>
            <input
              type="text"
              className="form-control"
              name="location"
              placeholder="New Location"
              value={location}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-primary btn-block">
            Submit
          </button>
          <br />
          {res && <h4 className="output">Stock updated successfully</h4>}
          {notFound && <h4 className="fail">Something went wrong</h4>}
          <Footer> </Footer>
        </form>
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};

UpdateStock.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(UpdateStock);
