import React, { Component, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";

export const CreateReview = ({ isAuthenticated }) => {
  const [reviewData, setReviewData] = useState({
    userName: "",
    productId: "",
    rating: "",
    comment: "",
  });
  const { userName, productId, rating, comment } = reviewData;
  const [res, setRes] = useState();
  const [notFound, setNotFound] = useState();
  const handleChange = (event) => {
    setReviewData({ ...reviewData, [event.target.name]: event.target.value });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    const reviewDetails = {
      userName: userName,
      productId: productId,
      rating: rating,
      comment: comment,
    };
    axios
      .post("http://localhost:9009/api/v1/review", reviewDetails)
      .then((res) => setRes(res.data))
      .catch((err) => setNotFound(true));
  };
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
          <h3>Review</h3>

          <div className="form-group">
            <label>Username</label>
            <input
              type="text"
              className="form-control"
              placeholder="User Name"
              name="userName"
              value={userName}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>Product ID</label>
            <input
              type="text"
              className="form-control"
              placeholder="Product ID"
              name="productId"
              value={productId}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>Rating</label>
            <input
              type="text"
              className="form-control"
              name="rating"
              placeholder="Rating"
              value={rating}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>Comment</label>
            <input
              type="text"
              className="form-control"
              name="comment"
              placeholder="Any Comments"
              value={comment}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-primary btn-block">
            Submit
          </button>
          <br />
        </form>
        {res && <h4 className="output">Review added successfully</h4>}
        {notFound && <h4 className="fail">Product Id does not exists.</h4>}
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};

CreateReview.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(CreateReview);
