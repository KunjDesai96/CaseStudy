import React, { Component, useState, useEffect } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";
import Table from "react-bootstrap/Table";

export const ShowStock = ({ isAuthenticated }) => {
  const [state, setState] = useState([
    { stockId: "", productId: "", quantity: "", location: "" },
  ]);
  //const  {productId, productName, category, description, expiryDate} = state;
  useEffect(() => {
    axios
      .get("http://localhost:9007/api/v1/stock/")
      .then((res) => setState(res.data));
  });
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <h4>Stock Details</h4>
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th>ID</th>
              <th>Product ID</th>
              <th>Quantity</th>
              <th>Location</th>
            </tr>
          </thead>
          <tbody>
            {state.map((item) => (
              <tr key={item.productId}>
                <td>{item.stockId}</td>
                <td>{item.productId}</td>
                <td>{item.quantity}</td>
                <td>{item.location}</td>
              </tr>
            ))}
          </tbody>
        </Table>
        <Footer> </Footer>
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};

ShowStock.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(ShowStock);
