import React, { Component } from 'react'
import { Link } from "react-router-dom";
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import Header from '../layouts/Header'
import Footer from '../layouts/Footer'

export const HomePage = ({ isAuthenticated }) => {
    if(isAuthenticated)
    {
    return (
        <div>
            <Header></Header>
            <form >
                <h3>This is the Home Page</h3>
                <div>
                    <p>Please choose a service from below</p>
                    <ul>
                        <br /><li><Link to="/landingProduct">Product</Link></li><br />
                        <li><Link to="/landingStock">Stock</Link></li><br />
                        <li><Link to="/landingPrice">Price</Link></li><br />
                        <li><Link to="/landingReview">Review</Link></li><br />
                        
                    </ul>
                </div>
               
            </form>
            <Footer> </Footer>
        </div>
     )
    }
    else
    {
      return <div> Please login to access this page</div>
    }
    }

HomePage.propTypes = {
    isAuthenticated: PropTypes.bool,
}

const mapStateToProps = (state) => ({
    isAuthenticated: state.auth.isAuthenticated

})

const mapDispatchToProps = {
    
}

export default connect(mapStateToProps, mapDispatchToProps)(HomePage)
