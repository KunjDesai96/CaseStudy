import React, { useState, Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";

export const UpdateReview = ({ isAuthenticated }) => {
  const [reviewData, setReviewData] = useState({
    reviewId: "",
    userName: "",
    productId: "",
    rating: "",
    comment: "",
  });
  const { reviewId, userName, productId, rating, comment } = reviewData;
  const [res, setRes] = useState();
  const [notFound, setNotFound] = useState();
  const handleChange = (event) => {
    setReviewData({ ...reviewData, [event.target.name]: event.target.value });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    const reviewDetails = {
      reviewId: reviewId,
      userName: userName,
      productId: productId,
      rating: rating,
      comment: comment,
    };
    axios
      .put(
        "http://localhost:9009/api/v1/review/" + reviewDetails.reviewId,
        reviewDetails
      )
      .then((res) => setRes(res.data))
      .catch((err) => setNotFound(true));
  };
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
          <h3>Update Review</h3>

          <div className="form-group">
            <label>Review id</label>
            <input
              type="text"
              className="form-control"
              placeholder="Review ID"
              name="reviewId"
              value={reviewId}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>User Name</label>
            <input
              type="text"
              className="form-control"
              placeholder="User Name"
              name="userName"
              value={userName}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>Product ID</label>
            <input
              type="text"
              className="form-control"
              placeholder="Product ID"
              name="productId"
              value={productId}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>New Rating</label>
            <input
              type="text"
              className="form-control"
              name="rating"
              placeholder="New rating"
              value={rating}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>New Comment</label>
            <input
              type="text"
              className="form-control"
              name="comment"
              placeholder="Any Comments"
              value={comment}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-primary btn-block">
            Submit
          </button>
        </form>
        <br />
        {res && <h4 className="output">Review updated successfully</h4>}
        {notFound && <h4 className="fail">Something went wrong</h4>}

        <Footer> </Footer>
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};
UpdateReview.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(UpdateReview);
