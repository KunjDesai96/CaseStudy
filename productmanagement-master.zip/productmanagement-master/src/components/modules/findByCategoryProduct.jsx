import React, { Component, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";
import Table from "react-bootstrap/Table";

export const FindByCategoryProduct = ({ isAuthenticated }) => {
  const [productData, setProductData] = useState({ category: "" });
  const { category } = productData;
  const [resData, setResData] = useState({
    productId: "",
    productName: "",
    description: "",
    expiryData: "",
  });
  const [notFound, setNotFound] = useState();
  const { productId, productName, description, expiryData } = resData;
  const handleChange = (event) => {
    setProductData({ ...productData, [event.target.name]: event.target.value });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    const productDetails = {
      category: category,
    };
    axios
      .get(
        "http://localhost:9006/api/v1/product/category/" + productData.category
      )
      .then((res) => setResData(res.data))
      .catch((err) => setNotFound(true));
  };
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
          <h3>Search Product By Category</h3>

          <div className="form-group">
            <label>Product Category</label>
            <input
              type="text"
              className="form-control"
              placeholder="Product category"
              name="category"
              value={category}
              onChange={handleChange}
            />
          </div>
          <button type="submit" className="btn btn-primary btn-block">
            Search
          </button>
        </form>
        <br />
        {notFound && <h4 className="fail">Something went wrong</h4>}
        {resData.productId != "" && (
          <Table striped bordered hover size="sm">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Description</th>
                <th>Expiry date</th>
              </tr>
            </thead>
            <tbody>
              {resData.map((item) => (
                <tr key={item.productId}>
                  <td>{item.productId}</td>
                  <td>{item.productName}</td>
                  <td>{item.category}</td>
                  <td>{item.description}</td>
                  <td>{item.expiryDate}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
        <Footer> </Footer>
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};
FindByCategoryProduct.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(FindByCategoryProduct);
