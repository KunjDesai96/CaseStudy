import React, { useState, Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";

export const UpdateProduct = ({ isAuthenticated }) => {
  const [productData, setProductData] = useState({
    productId: "",
    productName: "",
    category: "",
    description: "",
    expiryDate: "",
  });
  const {
    productId,
    productName,
    category,
    description,
    expiryDate,
  } = productData;
  const [res, setRes] = useState();
  const [notFound, setNotFound] = useState();
  const handleChange = (event) => {
    setProductData({
      ...productData,
      [event.target.name]: event.target.value,
    });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    const productDetails = {
      productId: productId,
      productName: productName,
      category: category,
      description: description,
      expiryDate: expiryDate,
    };
    axios
      .put(
        "http://localhost:9006/api/v1/product/" + productDetails.productId,
        productDetails
      )
      .then((res) => setRes(res.data))
      .catch((err) => setNotFound(true));
  };
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
          <h3>Update Product</h3>

          <div className="form-group">
            <label>Product ID</label>
            <input
              type="text"
              className="form-control"
              name="productId"
              placeholder="Product ID"
              value={productId}
              required
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>New Product Name</label>
            <input
              type="text"
              className="form-control"
              name="productName"
              placeholder="New Product Name"
              value={productName}
              required
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>New Category</label>
            <input
              type="text"
              className="form-control"
              name="category"
              placeholder="New Category"
              value={category}
              required
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>New Description</label>
            <input
              type="text"
              className="form-control"
              name="description"
              placeholder="New Description"
              value={description}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>New Expiry Date</label>
            <input
              type="date"
              className="form-control"
              name="expiryDate"
              placeholder="New Expiry Date"
              value={expiryDate}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-primary btn-block">
            Submit
          </button>
        </form>
        <br />
        {res && <h4 className="output">Product updated successfully</h4>}
        {notFound && <h4 className="fail">Something went wrong</h4>}

        <Footer> </Footer>
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};
UpdateProduct.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(UpdateProduct);
