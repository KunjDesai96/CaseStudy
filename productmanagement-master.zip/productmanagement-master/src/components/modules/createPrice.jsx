import React, { Component, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";

export const CreatePrice = ({ isAuthenticated }) => {
  const [priceData, setPriceData] = useState({ productId: "", priceValue: "" });
  const { productId, priceValue } = priceData;
  const [res, setRes] = useState();
  const [notFound, setNotFound] = useState();
  const handleChange = (event) => {
    setPriceData({ ...priceData, [event.target.name]: event.target.value });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    const priceDetails = {
      productId: productId,
      priceValue: priceValue,
    };
    axios
      .post("http://localhost:9008/api/v1/price/", priceDetails)
      .then( res => setRes(res.data)) 
      .catch((err) => setNotFound(true));
  };
  if (isAuthenticated) {
    return (
      <div>
        <Header></Header>
        <form onSubmit={onSubmit}>
          <h3>Price</h3>

          <div className="form-group">
            <label>Price</label>
            <input
              type="text"
              className="form-control"
              placeholder="Product ID"
              name="productId"
              value={productId}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>Price</label>
            <input
              type="text"
              className="form-control"
              name="priceValue"
              placeholder="Price per unit"
              value={priceValue}
              required
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-primary btn-block">
            Submit
          </button>
          <br />
        </form>
        {res && <h4 className="output">Price added successfully</h4>}
        {notFound && <h4 className="fail">Product Id does not exists.</h4>}
      </div>
    );
  } else {
    return <div> Please login to access this page</div>;
  }
};

CreatePrice.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(CreatePrice);
