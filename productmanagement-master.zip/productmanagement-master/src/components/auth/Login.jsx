import React, { Component, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { login } from "../../redux/actions/authAction";
import { Link, Redirect } from "react-router-dom";
import LoginHeader from "../layouts/LoginHeader";
import Footer from "../layouts/Footer";

export const Login = ({ login, isAuthenticated, login_failed }) => {
  const [formData, setFormData] = useState({ username: "", password: "" });
  const { username, password } = formData;
  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  const onSubmit = (e) => {
    e.preventDefault();
    console.log("Final state: " + username);
    console.log("password" + password);
    const loginUser = {
      username: username,
      password: password,
    };

    login(username, password);
  };
  if (isAuthenticated) {
    return <Redirect to="/HomePage"></Redirect>;
  } else if (login_failed) {
    return (
      <div>
        <LoginHeader></LoginHeader>
        <form onSubmit={onSubmit}>
          <h3>Sign In</h3>

          <div className="form-group">
            <label>Username</label>
            <input
              type="text"
              className="form-control"
              placeholder="Username"
              name="username"
              value={username}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              className="form-control"
              name="password"
              placeholder="Enter password"
              value={password}
              onChange={handleChange}
            />
          </div>
          <button type="submit" className="btn btn-primary btn-block">
            Submit
          </button>
          <br />
        </form>
        <div className="fail">Login failed!Please try again</div>
        <Footer> </Footer>
      </div>
    );
  } else {
    return (
      <div>
        <LoginHeader></LoginHeader>
        <form onSubmit={onSubmit}>
          <h3>Sign In</h3>

          <div className="form-group">
            <label>Username</label>
            <input
              type="text"
              className="form-control"
              placeholder="Username"
              name="username"
              value={username}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              className="form-control"
              name="password"
              placeholder="Enter password"
              value={password}
              onChange={handleChange}
            />
          </div>
          <button type="submit" className="btn btn-primary btn-block">
            Submit
          </button>
        </form>

        <Footer> </Footer>
      </div>
    );
  }
};

Login.propTypes = {
  login: PropTypes.func.isRequired,
  isAuthenticated: PropTypes.bool,
  login_failed: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
  login_failed: state.auth.login_failed,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, { login })(Login);
